import threading
import time
import json
import os
import random
from telethon import TelegramClient, sync
import shutil

# Define a global variable
timer = 0
upload_message = []
upload_message2 = []

# Function to increment the global variable
def increment_global_variable():
    global timer
    while True:
        timer += 1
        time.sleep(1)

increment_thread = threading.Thread(target=increment_global_variable)


current_directory = os.getcwd()
lildirectory_path = f'{current_directory}/liloutput'


increment_thread.start()


def get_autoposterlog():
    with open("autoposterlog.json", "r") as f:
        return json.load(f)

def get_accountinfo():
    with open("accounts.json", "r") as f:
        return json.load(f)

def add_video(channel, video):
    with open("autoposterlog.json", "r") as f:
        data = json.load(f)

    for account in data:
        if account["channel"] == channel:
            account["uploaded"].append(video)

    with open("autoposterlog.json", "w") as f:
        json.dump(data, f, indent=4)

def remove_video(video):
    with open("autoposterlog.json", "r") as f:
        data = json.load(f)

    for account in data:
        account["uploaded"].remove(video)

    with open("autoposterlog.json", "w") as f:
        json.dump(data, f, indent=4)




def set_last_upload(channel, time):
    with open("autoposterlog.json", "r") as f:
        data = json.load(f)

    for account in data:
        if account["channel"] == channel:
            account["last_upload"] = time

    with open("autoposterlog.json", "w") as f:
        json.dump(data, f, indent=4)



lastupload = 0

api_id = '20001746'
api_hash = 'ad25ff9fc57305256ab13ea27c611424'




#python autoposterv2.py
def test(username, channel, custom_message_frequency, custom_message, custom_message2_frequency, custom_message2, uploadedvideos, index):
    files = 0
    global upload_message
    global upload_message2
    for filename in os.listdir(lildirectory_path):
        file_path = os.path.join(lildirectory_path, filename)
        files+=1
    if files == 0:
        return
    filename = os.listdir(lildirectory_path)[random.randint(0, files)-1]
    filename = os.listdir(lildirectory_path)[random.randint(0, files)-1]
    file_path = os.path.join(lildirectory_path, filename)
    while True:
        if file_path not in uploadedvideos:
            break
        filename = os.listdir(lildirectory_path)[random.randint(0, files)-1]
        filename = os.listdir(lildirectory_path)[random.randint(0, files)-1]
        file_path = os.path.join(lildirectory_path, filename)

    add_video(channel, file_path)

    if os.path.isfile(file_path):
        try:
            with TelegramClient(username, api_id, api_hash) as client:
                client.start()
                client.send_file(channel, file_path)
                upload_message[index] +=1
                upload_message2[index] +=1
                if upload_message[index] > int(custom_message_frequency):
                    upload_message[index] = 0
                    client.send_message(channel, custom_message)
                if upload_message2[index] > int(custom_message2_frequency):
                    upload_message2[index] = 0
                    client.send_message(channel, custom_message2)
        except Exception as e:
            print(f"Error processing {filename}: {e}")

    elif os.path.isdir(file_path):  # If it's a directory, upload all files within it
        try:
            with TelegramClient(username, api_id, api_hash) as client:
                videos = []
                for dirpath, _, filenames in os.walk(file_path):
                    for filename in filenames:
                        file_to_upload = os.path.join(dirpath, filename)
                        videos.append(file_to_upload)

                if videos:
                    media = []
                    for video in videos:
                        media.append(video)
                    print(media)

                    # Send all videos in one message
                client.start()
                client.send_file(channel, media)
                upload_message[index] +=1
                upload_message2[index] +=1
                if upload_message[index] > int(custom_message_frequency):
                    upload_message[index] = 0
                    client.send_message(channel, custom_message)
                if upload_message2[index] > int(custom_message2_frequency):
                    upload_message2[index] = 0
                    client.send_message(channel, custom_message2)
            print("REMOVEING")
        except Exception as e:
            print(f"Error processing files in {file_path}: {e}")



    print(files)


def video_check(videos, video):
    arrayamount = len(videos)
    for i in range(arrayamount):
        if video not in videos[i]:
            return False
    return True



def remove_files():
    log = get_autoposterlog()
    videos = []
    for account in log:
        videos.append(account["uploaded"])
    for video in log[0]["uploaded"]:
        if video_check(videos, video) == True:
            if os.path.isfile(video):
                os.remove(video)
                remove_video(video)
            else:
                shutil.rmtree(video)
                remove_video(video)
                
accounts = get_accountinfo()
for i in range(len(accounts)):
    upload_message.append(0)
    upload_message2.append(0)

while True:
    autoposterlog = get_autoposterlog()
    accounts = get_accountinfo()
    for i in range(len(accounts)):
        if int(accounts[i]["postersettings"]["upload_every"]) < timer-autoposterlog[i]["last_upload"]:
            test("@davcuder", autoposterlog[i]["channel"], accounts[i]["postersettings"]["custom_message_frequency"], accounts[i]["postersettings"]["custom_message"], accounts[i]["postersettings"]["custom_message2_frequency"], accounts[i]["postersettings"]["custom_message2"], autoposterlog[i]["uploaded"], i)
            set_last_upload(autoposterlog[i]["channel"], timer)
            remove_files()
        print("yessir")
    time.sleep(1)
