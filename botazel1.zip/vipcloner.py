import asyncio
import json
import os.path
from telethon.sync import TelegramClient
from telethon.tl.types import InputMessagesFilterVideo

api_id = '20001746'
api_hash = 'ad25ff9fc57305256ab13ea27c611424'

# Initialize your Telegram client
client = TelegramClient('@MasterSheikh2', api_id, api_hash)

async def load_processed_ids():
    if os.path.exists('processed_ids.json'):
        with open('processed_ids.json', 'r') as f:
            return json.load(f)
    else:
        return {'downloaded': [], 'uploaded': set()}

async def save_processed_ids(processed_ids):
    with open('processed_ids.json', 'w') as f:
        json.dump(processed_ids, f)

async def download_and_upload_videos(channel, destination_channel, vid_amount):
    processed_ids = await load_processed_ids()
    current = 0
    video_bundle = []
    
    async for message in client.iter_messages(channel, filter=InputMessagesFilterVideo):
        if message.media is not None and message.id not in processed_ids['downloaded']:
            current += 1
            try:
                await client.download_media(message.media, f'vipvids/{message.id}.mp4')
                print("Downloaded!")
                video_bundle.append(f'vipvids/{message.id}.mp4')
                processed_ids['downloaded'].append(message.id)
                await save_processed_ids(processed_ids)
            except Exception as e:
                print(f"An error occurred: {e}")
                if "seconds" in str(e):
                    timenew = int(str(e).split(' ')[3])
                    await asyncio.sleep(timenew)
            
            if current >= vid_amount:
                if video_bundle:
                    try:
                        await client.send_file(destination_channel, video_bundle)
                        print("Uploaded!")


                        for file_path in video_bundle:
                            os.remove(file_path)
                        print("Deleted uploaded videos.")

                        processed_ids['uploaded'].extend(message.id for message in video_bundle)
                        await save_processed_ids(processed_ids)
                        

                        
                    except Exception as e:
                        print(f"An error occurred: {e}")
                    video_bundle = []
                    current = 0


async def main():
    await client.start()

    tasks2 = [
        download_and_upload_videos('https://t.me/HornyAsian', 'https://t.me/+y_B1NzZWLY8wOWE0', 10),
        download_and_upload_videos('https://t.me/internet_wild_girlss', 'https://t.me/+y_B1NzZWLY8wOWE0', 10),
        download_and_upload_videos('https://t.me/HornyZoomers', 'https://t.me/+y_B1NzZWLY8wOWE0', 10),
        download_and_upload_videos('https://t.me/OnlyFans_Base', 'https://t.me/+y_B1NzZWLY8wOWE0', 10),
        download_and_upload_videos('https://t.me/+vkP8u8_PKrdlNzk0', 'https://t.me/+y_B1NzZWLY8wOWE0', 5)
    ]

    tasks = [
        download_and_upload_videos(2070085990, 2105396533, 30)
    ]

    await asyncio.gather(*tasks)


with client:
    asyncio.get_event_loop().run_until_complete(main())
