from telethon.sync import TelegramClient
from telethon.tl.functions.channels import GetChannelsRequest
from telethon.tl.types import InputChannel

# Replace with your own values
api_id = '20001746'
api_hash = 'ad25ff9fc57305256ab13ea27c611424'

async def main():
    # Start the client
    async with TelegramClient('@MasterSheikh2', api_id, api_hash) as client:
        # Authenticate the client
        await client.start()
        
        # Get the dialogs (conversations) including channels
        dialogs = await client.get_dialogs()
        
        for dialog in dialogs:
            if dialog.is_channel:
                # Check if the dialog is a channel
                print(f"Channel ID: {dialog.entity.id}, Channel Name: {dialog.entity.title}")

# Running the main function
if __name__ == '__main__':
    import asyncio
    asyncio.run(main())
